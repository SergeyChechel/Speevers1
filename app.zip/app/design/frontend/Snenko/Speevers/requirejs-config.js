const config = {
    map: {
        '*': {
            'happy-customer-slider': 'js/happy-customer-slider',
            'mage/menu': 'mage/menu'
        }
    }
};
